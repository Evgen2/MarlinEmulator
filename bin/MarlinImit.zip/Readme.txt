Features support
1. ip connection on 8876 port
2. EEPROM read/write emulation with file eeprom.dat
3. Physcial parameters in file MarlinImit.cfg
3.1 Max/min move fileld
3.2 Max/min endstop (on=triggered) position
3.3 Bed & extruder temperature & heating imitation